package Demo.Entity;

import java.util.Date;

public class Substation {
    private String substationId;
    private String name;
    private String location;
    private String voltageLevel;
    private Integer transformerCount;
    private Date operationTime;
    private String managerId;
    private String contact;
    
    // getters and setters
    public String getSubstationId() { return substationId; }
    public void setSubstationId(String substationId) { this.substationId = substationId; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    
    public String getVoltageLevel() { return voltageLevel; }
    public void setVoltageLevel(String voltageLevel) { this.voltageLevel = voltageLevel; }
    
    public Integer getTransformerCount() { return transformerCount; }
    public void setTransformerCount(Integer transformerCount) { this.transformerCount = transformerCount; }
    
    public Date getOperationTime() { return operationTime; }
    public void setOperationTime(Date operationTime) { this.operationTime = operationTime; }
    
    public String getManagerId() { return managerId; }
    public void setManagerId(String managerId) { this.managerId = managerId; }
    
    public String getContact() { return contact; }
    public void setContact(String contact) { this.contact = contact; }
}