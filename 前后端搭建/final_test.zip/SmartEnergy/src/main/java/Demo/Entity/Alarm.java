package Demo.Entity;

import java.math.BigDecimal;
import java.util.Date;  // 改为 Date

public class Alarm {
    private Long alarmId;
    private String alarmType;
    private String deviceId;
    private Date occurTime;  // 改为 Date
    private String alarmLevel;
    private String alarmContent;
    private String handleStatus;
    private BigDecimal triggerThreshold;
    
    // getters and setters
    public Long getAlarmId() { return alarmId; }
    public void setAlarmId(Long alarmId) { this.alarmId = alarmId; }
    
    public String getAlarmType() { return alarmType; }
    public void setAlarmType(String alarmType) { this.alarmType = alarmType; }
    
    public String getDeviceId() { return deviceId; }
    public void setDeviceId(String deviceId) { this.deviceId = deviceId; }
    
    public Date getOccurTime() { return occurTime; }  // 改为 Date
    public void setOccurTime(Date occurTime) { this.occurTime = occurTime; }  // 改为 Date
    
    public String getAlarmLevel() { return alarmLevel; }
    public void setAlarmLevel(String alarmLevel) { this.alarmLevel = alarmLevel; }
    
    public String getAlarmContent() { return alarmContent; }
    public void setAlarmContent(String alarmContent) { this.alarmContent = alarmContent; }
    
    public String getHandleStatus() { return handleStatus; }
    public void setHandleStatus(String handleStatus) { this.handleStatus = handleStatus; }
    
    public BigDecimal getTriggerThreshold() { return triggerThreshold; }
    public void setTriggerThreshold(BigDecimal triggerThreshold) { this.triggerThreshold = triggerThreshold; }
}