package Demo.Entity;

import java.util.Date;
import java.math.BigDecimal;

public class CircuitData {
    private Long dataId;
    private String substationId;
    private String circuitId;
    private Date collectTime;
    private BigDecimal voltage;
    private BigDecimal current;
    private BigDecimal activePower;
    private BigDecimal reactivePower;
    private BigDecimal powerFactor;
    private BigDecimal forwardActiveEnergy;
    private BigDecimal reverseActiveEnergy;
    private String switchStatus;
    private BigDecimal cableTemp;
    private BigDecimal capacitorTemp;
    private String dataStatus;
    
    // getters and setters
    public Long getDataId() { return dataId; }
    public void setDataId(Long dataId) { this.dataId = dataId; }
    
    public String getSubstationId() { return substationId; }
    public void setSubstationId(String substationId) { this.substationId = substationId; }
    
    public String getCircuitId() { return circuitId; }
    public void setCircuitId(String circuitId) { this.circuitId = circuitId; }
    
    public Date getCollectTime() { return collectTime; }
    public void setCollectTime(Date collectTime) { this.collectTime = collectTime; }
    
    public BigDecimal getVoltage() { return voltage; }
    public void setVoltage(BigDecimal voltage) { this.voltage = voltage; }
    
    public BigDecimal getCurrent() { return current; }
    public void setCurrent(BigDecimal current) { this.current = current; }
    
    public BigDecimal getActivePower() { return activePower; }
    public void setActivePower(BigDecimal activePower) { this.activePower = activePower; }
    
    public BigDecimal getReactivePower() { return reactivePower; }
    public void setReactivePower(BigDecimal reactivePower) { this.reactivePower = reactivePower; }
    
    public BigDecimal getPowerFactor() { return powerFactor; }
    public void setPowerFactor(BigDecimal powerFactor) { this.powerFactor = powerFactor; }
    
    public BigDecimal getForwardActiveEnergy() { return forwardActiveEnergy; }
    public void setForwardActiveEnergy(BigDecimal forwardActiveEnergy) { this.forwardActiveEnergy = forwardActiveEnergy; }
    
    public BigDecimal getReverseActiveEnergy() { return reverseActiveEnergy; }
    public void setReverseActiveEnergy(BigDecimal reverseActiveEnergy) { this.reverseActiveEnergy = reverseActiveEnergy; }
    
    public String getSwitchStatus() { return switchStatus; }
    public void setSwitchStatus(String switchStatus) { this.switchStatus = switchStatus; }
    
    public BigDecimal getCableTemp() { return cableTemp; }
    public void setCableTemp(BigDecimal cableTemp) { this.cableTemp = cableTemp; }
    
    public BigDecimal getCapacitorTemp() { return capacitorTemp; }
    public void setCapacitorTemp(BigDecimal capacitorTemp) { this.capacitorTemp = capacitorTemp; }
    
    public String getDataStatus() { return dataStatus; }
    public void setDataStatus(String dataStatus) { this.dataStatus = dataStatus; }
}