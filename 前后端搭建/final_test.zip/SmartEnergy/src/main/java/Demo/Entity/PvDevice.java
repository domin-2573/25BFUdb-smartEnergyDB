package Demo.Entity;

import java.util.Date;
import java.math.BigDecimal;

public class PvDevice {
    private String deviceId;
    private String deviceType;
    private String installLocation;
    private BigDecimal capacity;
    private Date operationTime;
    private Integer calibrationCycle;
    private String operationStatus;
    private String communicationProtocol;
    
    // getters and setters
    public String getDeviceId() { return deviceId; }
    public void setDeviceId(String deviceId) { this.deviceId = deviceId; }
    
    public String getDeviceType() { return deviceType; }
    public void setDeviceType(String deviceType) { this.deviceType = deviceType; }
    
    public String getInstallLocation() { return installLocation; }
    public void setInstallLocation(String installLocation) { this.installLocation = installLocation; }
    
    public BigDecimal getCapacity() { return capacity; }
    public void setCapacity(BigDecimal capacity) { this.capacity = capacity; }
    
    public Date getOperationTime() { return operationTime; }
    public void setOperationTime(Date operationTime) { this.operationTime = operationTime; }
    
    public Integer getCalibrationCycle() { return calibrationCycle; }
    public void setCalibrationCycle(Integer calibrationCycle) { this.calibrationCycle = calibrationCycle; }
    
    public String getOperationStatus() { return operationStatus; }
    public void setOperationStatus(String operationStatus) { this.operationStatus = operationStatus; }
    
    public String getCommunicationProtocol() { return communicationProtocol; }
    public void setCommunicationProtocol(String communicationProtocol) { this.communicationProtocol = communicationProtocol; }
}